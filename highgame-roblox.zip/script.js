document.addEventListener("DOMContentLoaded", function () {
    const shapes = document.querySelectorAll(".shape");

    shapes.forEach(shape => {
        let speed = Math.random() * 2 + 1;
        let direction = Math.random() < 0.5 ? 1 : -1;
        let angle = Math.random() * 360;

        function animate() {
            angle += speed * direction;
            shape.style.transform = `rotate(${angle}deg)`;
            requestAnimationFrame(animate);
        }

        animate();
    });
});
